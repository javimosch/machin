/* Shim: `#include <regex.h>` in machin-generated C resolves here on targets
   without a libc regex (Windows/mingw), pulling in the vendored TRE POSIX
   API. On POSIX targets this file is never on the include path. */
#include <tre/regex.h>

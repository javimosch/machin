/* Pre-generated tre-config.h for the machin vendored build (no autotools).
   Byte-oriented POSIX ERE: TRE_MULTIBYTE/TRE_WCHAR/TRE_APPROX/
   TRE_USE_ALLOCA stay undefined so regexec works on raw bytes — the same
   semantics glibc regexec has in the C locale, which is what the native
   build's regex_* builtins already provide for UTF-8 text. Vendored
   patches vs upstream: TRE_REGEX_T_FIELD (configure normally defines it)
   and tre-internal.h's ALIGN uses size_t not long (LLP64/Windows fix). */
#ifndef TRE_CONFIG_H
#define TRE_CONFIG_H

#define HAVE_MALLOC_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_WCHAR_H 1
#define TRE_REGEX_T_FIELD value
#define TRE_VERSION "0.8.0"
#define TRE_VERSION_1 8
#define TRE_VERSION_2 0

#endif /* TRE_CONFIG_H */
